package com.example.PayrollSystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.PayrollSystem.model.Admin;
import com.example.PayrollSystem.model.PaySlip;
import com.example.PayrollSystem.model.User;
import com.example.PayrollSystem.services.AdminService;
import com.example.PayrollSystem.services.PaySlipServices;
import com.example.PayrollSystem.services.UserService;

import java.util.List;

@RestController
@RequestMapping("/api")  // All endpoints will start with /api
public class ApplicationController {

    @Autowired
    private UserService userService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private PaySlipServices payService;

    // ✅ Simple test
    @GetMapping("/home")
    public String hello() {
        return "Welcome to Payroll System API";
    }

    // ✅ Register a new User
    @PostMapping("/users")
    public User saveUser(@RequestBody User user) {
        userService.saveMyUser(user);
        return user;
    }

    // ✅ Get all Users
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.showAllUsers();
    }

    // ✅ Get User by username
    @GetMapping("/users/{username}")
    public User getUser(@PathVariable String username) {
        return userService.editUser(username);
    }

    // ✅ Delete User by ID
    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable int id) {
        userService.deleteMyUser(id);
        return "User deleted with id " + id;
    }

    // ✅ User Login
    @PostMapping("/login")
    public String loginUser(@RequestBody User user) {
        User found = userService.findByUsernameAndPassword(user.getUsername(), user.getPassword());
        if (found != null) {
            return "Login Successful for user: " + user.getUsername();
        }
        return "Invalid Username or Password";
    }

    // ✅ Admin Login
    @PostMapping("/admin/login")
    public String loginAdmin(@RequestBody Admin admin) {
        Admin found = adminService.findByEmailAndPassword(admin.getEmail(), admin.getPassword());
        if (found != null) {
            return "Admin Login Successful for: " + admin.getEmail();
        }
        return "Invalid Admin credentials";
    }

    // ✅ Save PaySlip
    @PostMapping("/payslips")
    public PaySlip savePayslip(@RequestBody PaySlip payslip) {
        payService.savePayslip(payslip);
        return payslip;
    }

    // ✅ Find PaySlip by Email
    @GetMapping("/payslips/{email}")
    public PaySlip getPayslipByEmail(@PathVariable String email) {
        return payService.findByEmail(email);
    }
}
