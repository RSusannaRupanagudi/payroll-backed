package com.example.PayrollSystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.PayrollSystem.model.Admin;

public interface AdminRepo extends CrudRepository<Admin, Integer> {

    // Find admin by email only
	public Admin findByEmailAndPassword(String email, String password);
}



